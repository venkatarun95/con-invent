appletviewer -J-Djava.security.policy=permit.policy CGL.html
