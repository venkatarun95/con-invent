appletviewer -J-Djava.security.policy=CGL/CGL/permit.policy CGL/CGL/CGL.html
