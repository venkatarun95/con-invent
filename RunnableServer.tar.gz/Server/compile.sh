javac CentralServer.java Authentication.java ClientServer.java Scoreboard.java ChallengeHandler.java GarbageCollector.java SaveStatus.java
